# PhantomRPC Research Repository

This repository is a research repository where you can find all the resources for PhantomRPC research that allows local privilege escalation.  
More about the research can be found here:  
https://securelist.com/phantomrpc-rpc-vulnerability/119428/

---

## Directory Structure

| Directory | Description |
|----------|------------|
| POCs | Research proof-of-concept code |
| toolset | Files used for collecting vulnerable processes |

---

## POCs

Set of POCs written in C that mimic different RPC servers exposed by system services.  
Each one implements a function for a specific interface of an RDP server, in addition to a specific endpoint.

### Compile each server

```bash
midl ExampleInterface.idl /app_config
cl.exe server.c ExampleInterface_s.c
```

### Available POCs

| POC | Description |
|-----|------------|
| TERM | Terminal Service RPC server |
| DHCP | DHCP Client Service RPC server |
| TIME | Windows Time Service RPC server |

> **Note:**  
> These codes are meant to be simple POCs for research purposes only.  
> They will spawn `cmd.exe` with elevated privileges.  
> Use them for testing only. Do NOT use in production environments.  
> I am not responsible for any illegal usage.

---

## Toolset

Set of files that can be used for collecting vulnerable processes in Windows systems that try to connect to non-existing RPC servers.

### Steps to collect the data

#### 1. Start ETW RPC capturing

```bash
logman create trace "NameOfTheTrace" -p "{6ad52b32-d609-4be9-ae07-ce8dae937e39}" 0xFFFFFFFFFFFFFFFF 4 -o "YourOutputPath"
logman start "NameOfTheTrace"
```

Generate events as described in the whitepaper (link above).

---

#### 2. Convert ETL to JSON using Etw2Json

Tool repository: https://github.com/microsoft/ETW2JSON

```bash
Etw2Json.exe "YourEtlFile" --output="YourJsonOutput"
```

---

#### 3. Run the Python tool to extract events

```bash
python enricher.py "JsonInputFile"
```

---

### Toolset Files

| File | Description |
|------|------------|
| enricher.py | Python tool for filtering and mapping ETW JSON files |
| interfaces.json | Windows interfaces database from https://github.com/cyberark/RPCMon/blob/main/DB/RPC_UUID_Map_Windows10_1909_18363.1977.rpcdb.json |

---

## Authors and Acknowledgment

Haidar Kabibo  
Kaspersky Security Services  
X (Twitter): https://x.com/haider_kabibo

---

## License

This software is provided under the MIT Software License.
