#!/usr/bin/env python3
import json
import csv
import sys
import argparse
from pathlib import Path

# ---------- helpers ----------

def last_segment_token(s: str) -> str:
    """
    Normalize an endpoint-ish string to its last segment for matching against Id=5 Endpoint.
    Examples:
      '\\\\RPC Control\\\\TermSrvApi' -> 'TermSrvApi'
      '\\\\.\\PIPE\\browser'         -> 'browser'
      '\\\\pipe\\\\blabal'           -> 'blabal'
      '{DB9587E4-...}'               -> '{DB9587E4-...}'  (unchanged)
    """
    if not s:
        return ""
    t = s.replace("/", "\\").strip()
    parts = [p for p in t.split("\\") if p]  # drop empty parts from leading backslashes
    return parts[-1] if parts else t

def norm_key(token: str) -> str:
    """Case-insensitive key for matching only (we keep original strings in output)."""
    return (token or "").casefold()

def iter_events_by_id(data, event_id):
    for wrap in data.get("Events", []) or []:
        e = wrap.get("Event") or {}
        if e.get("Id") == event_id:
            yield e

# ---------- extraction ----------

def collect_unique_triples_from_id1(data, status_set):
    """
    From Id==1 events, collect UNIQUE (ImageName, ProcessID, EndPoint)
    where any Properties entry has Status in status_set and any Param has non-empty UnicodeValue.

    NOTE: We *read* from Param.UnicodeValue, but we store/output it as EndPoint.
    """
    seen = set()
    rows = []
    for e in iter_events_by_id(data, 1):
        event_pid = e.get("ProcessId")
        for p in (e.get("Properties") or []):
            status = p.get("Status")
            if status not in status_set:
                continue
            img = p.get("ImageName")
            pid = p.get("ProcessID", event_pid)
            for par in (p.get("Params") or []):
                uv = par.get("UnicodeValue")
                if not uv:
                    continue
                triple = (img, pid, uv)
                if triple in seen:
                    continue
                seen.add(triple)
                rows.append({
                    "ImageName": img,
                    "ProcessID": pid,
                    "EndPoint": uv,  # output name is EndPoint (even though input key is UnicodeValue)
                    "_EndpointKey": norm_key(last_segment_token(uv)),  # internal key for matching
                })
    return rows

def build_lookup_from_id5(data):
    """
    From Id==5 events, map (ProcessId, last-seg(Endpoint) case-insensitive) ->
      { InterfaceUuid, ImpersonationLevel, ProcNum, ts }

    Keep the latest by Timestamp per key.

    ProcNum may appear on the Event, or on Properties; we check both.
    """
    idx = {}
    for e in iter_events_by_id(data, 5):
        ts  = e.get("Timestamp", 0)
        pid = e.get("ProcessId")

        # sometimes on Event
        imp_ev = e.get("ImpersonationLevel")
        proc_ev = e.get("ProcNum")

        for p in (e.get("Properties") or []):
            ep = p.get("Endpoint")
            if pid is None or not ep:
                continue

            key = (pid, norm_key(last_segment_token(ep)))

            iface = p.get("InterfaceUuid") or p.get("InterfaceId")
            imp   = imp_ev if imp_ev is not None else p.get("ImpersonationLevel")

            # ProcNum can be on Event or Property (prefer Event if present)
            proc = proc_ev if proc_ev is not None else p.get("ProcNum")

            cur = idx.get(key)
            if cur is None or ts > cur["ts"]:
                idx[key] = {
                    "InterfaceUuid": iface,
                    "ImpersonationLevel": imp,
                    "ProcNum": proc,
                    "ts": ts
                }
    return idx

def enrich(rows, idx):
    out = []
    for r in rows:
        key = (r.get("ProcessID"), r.get("_EndpointKey"))
        m = idx.get(key) or {}
        out.append({
            "ImageName": r.get("ImageName"),
            "ProcessID": r.get("ProcessID"),
            "EndPoint": r.get("EndPoint"),
            "InterfaceUuid": m.get("InterfaceUuid"),
            "ImpersonationLevel": m.get("ImpersonationLevel"),
            "ProcNum": m.get("ProcNum"),
        })
    return out

# ---------- interfaces lookup ----------

def load_interfaces_map(path: Path):
    """
    Load interfaces.json as a dict keyed by lowercased GUID string.
    Expected shape:
      {
        "54f96d15-d9a7-4422-bd32-8b0cebd00400": {
           "Module": "...", "ModulePath": "...", "ProceduresCount": 11, ...
        },
        ...
      }
    """
    try:
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception as e:
        print(f"WARNING: failed to read interfaces file {path}: {e}", file=sys.stderr)
        return {}

    return {(k or "").casefold(): v for k, v in raw.items()}

def attach_interface_metadata(rows, iface_map):
    """
    For each row, if InterfaceUuid is set and present in iface_map (case-insensitive),
    attach Module, ModulePath, ProceduresCount.
    """
    for r in rows:
        iface = r.get("InterfaceUuid")
        meta = iface_map.get((iface or "").casefold())
        if meta:
            r["Module"] = meta.get("Module")
            r["ModulePath"] = meta.get("ModulePath")
            pc = meta.get("ProceduresCount")
            if pc is None and isinstance(meta.get("Procedures"), list):
                pc = len(meta["Procedures"])
            r["ProceduresCount"] = pc
        else:
            r["Module"] = None
            r["ModulePath"] = None
            r["ProceduresCount"] = None
    return rows

# ---------- I/O ----------

def write_json(path: Path, rows):
    with path.open("w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)

def write_csv(path: Path, rows):
    fields = [
        "ImageName", "ProcessID", "EndPoint",
        "InterfaceUuid", "ImpersonationLevel", "ProcNum",
        "Module", "ModulePath", "ProceduresCount"
    ]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})

# ---------- main ----------

def parse_args():
    ap = argparse.ArgumentParser(
        description="Enrich RPC ETW Id=1 (Stop) events with Id=5 (Start) metadata and interface details."
    )
    ap.add_argument("input", help="Path to merged events JSON (top-level { 'Events': [ {'Event': {...}}, ... ] })")
    ap.add_argument("--statuses", default="1722,2",
                    help="Comma-separated Status codes to include from Id=1 (default: 1722,2)")
    ap.add_argument("--interfaces", default="interfaces.json",
                    help="Path to interfaces.json (GUID -> metadata). Default: interfaces.json")
    ap.add_argument("--json-out", help="Optional path for JSON output (default: <input>.enriched.json)")
    ap.add_argument("--csv-out", help="Optional path for CSV output (default: <input>.enriched.csv)")
    return ap.parse_args()

def main():
    args = parse_args()
    infile = Path(args.input)

    try:
        with infile.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"ERROR: failed to read JSON from {infile}: {e}", file=sys.stderr)
        sys.exit(2)

    # parse status set
    try:
        status_set = {int(x.strip()) for x in args.statuses.split(",") if x.strip() != ""}
    except ValueError:
        print(f"ERROR: --statuses must be a comma-separated list of integers (got: {args.statuses})", file=sys.stderr)
        sys.exit(2)

    # pipeline
    id1_rows = collect_unique_triples_from_id1(data, status_set)
    id5_idx  = build_lookup_from_id5(data)
    enriched = enrich(id1_rows, id5_idx)

    # attach interface metadata
    iface_map = load_interfaces_map(Path(args.interfaces))
    enriched  = attach_interface_metadata(enriched, iface_map)

    # outputs
    out_json = Path(args.json_out) if args.json_out else infile.with_suffix(".enriched.json")
    out_csv  = Path(args.csv_out)  if args.csv_out  else infile.with_suffix(".enriched.csv")

    write_json(out_json, enriched)
    write_csv(out_csv, enriched)

    print(f"Wrote {out_json} and {out_csv} with {len(enriched)} rows")
    if not enriched:
        print("Note: no matches found. Check your --statuses, ProcessID presence, and Endpoint/UnicodeValue shapes.")
    if not iface_map:
        print("Note: no interface metadata loaded (missing/empty interfaces.json).")

if __name__ == "__main__":
    main()
